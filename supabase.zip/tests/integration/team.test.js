// End-to-end team workflow (the hackathon demo scenario) through the real
// router and handlers, against an in-memory Supabase stand-in and the
// simulated agent. Run: npm run test:integration
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createFakeSupabase } from './fake-supabase.js';

const fake = createFakeSupabase();
globalThis.__TEST_DB__ = fake;
delete process.env.ANTHROPIC_API_KEY;
const { default: handler } = await import('../../api/index.js');

const owner = fake.addUser('Olivia');
const projectId = 'p-campuseats';
fake.tables.projects = [{ id: projectId, name: 'CampusEats', description: 'Campus food ordering', owner_id: owner.id }];
fake.tables.project_members = [{ project_id: projectId, user_id: owner.id, role: 'owner', status: 'active', department: null }];

let people = {};

/** Calls an endpoint as the owner, acting as a demo person when `as` is given. */
async function call(method, route, { body = {}, query = {}, as } = {}) {
  let status = 200;
  let json;
  const res = { status(c) { status = c; return res; }, json(o) { json = o; return res; } };
  const headers = { authorization: `Bearer ${owner.token}`, ...(as ? { 'x-act-as': people[as] } : {}) };
  const req = { method, headers, body: { projectId, ...body }, query: { route, projectId, ...query } };
  await handler(req, res);
  if (status >= 400) throw new Error(`${method} ${route} → ${status}: ${json?.error}`);
  return json;
}

const start = (as, text) => call('POST', 'team/task/start', { as, body: { text } });
const confirmPlan = (as, t) => call('POST', 'team/task/plan-decision', { as, body: { taskId: t.id } });
const current = async (as) => (await call('GET', 'team/task/current', { as })).task;

test('demo setup seeds departments, people, context and files', async () => {
  const r = await call('POST', 'team/demo/setup');
  people = Object.fromEntries(r.people.map((p) => [p.name.toLowerCase(), p.id]));
  const boot = await call('GET', 'team/bootstrap', { as: 'rohan' });
  assert.equal(boot.me.isDeveloper, true);
  assert.equal(boot.departments.length, 3);
  assert.equal(boot.agentMode, 'mock');
});

test('only the owner can act as demo people', async () => {
  const intruder = fake.addUser('Mallory');
  fake.tables.project_members.push({ project_id: projectId, user_id: intruder.id, role: 'worker', status: 'active', department: 'frontend' });
  let status;
  const res = { status(c) { status = c; return res; }, json() { return res; } };
  await handler({ method: 'GET', headers: { authorization: `Bearer ${intruder.token}`, 'x-act-as': people.kabir }, body: {}, query: { route: 'team/bootstrap', projectId } }, res);
  assert.equal(status, 403);
});

test('conflict warning before acting', async () => {
  const t = await start('meera', 'Restyle the checkout with Bootstrap');
  assert.equal(t.status, 'needs_conflict_decision');
  assert.equal(t.conflicts[0].sectionId, 'fe-conventions');
  await call('POST', 'team/task/conflict-decision', { as: 'meera', body: { taskId: t.id, choice: 'cancel' } });
});

test('demo scenario: cross-department change, mid-task alert, outdated submission, merge', async () => {
  let rohan = await start('rohan', 'Build the checkout page with a card payment form');
  assert.equal(rohan.status, 'awaiting_plan_approval');
  rohan = await confirmPlan('rohan', rohan);
  assert.equal(rohan.status, 'done');
  assert.ok(rohan.changedFiles.includes('web/checkout.html'));

  const arjun = await start('arjun', 'Add an order status endpoint');
  assert.ok(!arjun.relevantSectionIds.includes('c-payment-api'), 'an order endpoint does not depend on payments');
  await confirmPlan('arjun', arjun);

  const isha = await confirmPlan('isha', await start('isha', 'Switch from card payments to UPI only'));
  const sub = await call('POST', 'team/task/submit', { as: 'isha', body: { taskId: isha.id, why: 'CampusPay is ending card support' } });
  assert.equal(sub.submitted, true);

  const { proposal } = await call('POST', 'team/review/decide', { as: 'kabir', body: { submissionId: sub.submission.id, action: 'approve' } });
  assert.equal(proposal.impact.scope, 'cross_department');
  assert.deepEqual([...proposal.impact.affectedDepartments].sort(), ['backend', 'frontend']);
  assert.ok(proposal.impact.notify.some((n) => n.userId === people.rohan && n.affectsActiveWork));
  assert.ok(!proposal.changes.some((c) => c.sectionId === 'fe-conventions'), '.card CSS class is not a payment card');
  assert.ok(proposal.impact.unaffected.some((u) => u.userId === people.arjun));

  await call('POST', 'team/proposals/confirm', { as: 'kabir', body: { proposalId: proposal.id } });
  const ctx = await call('GET', 'team/context', { as: 'rohan' });
  assert.equal(ctx.central.find((s) => s.id === 'c-payment-method').version, 2);
  assert.equal(ctx.scopeVersions.central, 3, 'one confirmed update bumps a scope once');

  rohan = await current('rohan');
  assert.equal(rohan.status, 'needs_context_decision');
  assert.match(rohan.contextAlert.relation, /card/);
  assert.equal((await current('arjun')).status, 'done', 'Arjun is undisturbed');

  rohan = (await call('POST', 'team/task/context-decision', { as: 'rohan', body: { taskId: rohan.id, choice: 'adjust', newText: rohan.contextAlert.suggestedTask } }));
  assert.equal(rohan.status, 'awaiting_plan_approval');
  rohan = await confirmPlan('rohan', rohan);
  assert.match(rohan.summary, /UPI/);

  const queue = (await call('GET', 'team/review/queue', { as: 'ananya' })).items;
  const meera = queue.find((s) => s.userId === people.meera);
  assert.ok(meera.outdated.some((o) => o.sectionId === 'c-payment-method'));
  await call('POST', 'team/review/decide', { as: 'ananya', body: { submissionId: meera.id, action: 'send_back', note: 'Payment is UPI only now.' } });

  const rsub = await call('POST', 'team/task/submit', { as: 'rohan', body: { taskId: rohan.id, why: 'UPI checkout' } });
  assert.equal(rsub.submitted, true, 'pre-submit check passes after adjusting');
  const approved = await call('POST', 'team/review/decide', { as: 'ananya', body: { submissionId: rsub.submission.id, action: 'approve' } });
  assert.equal(approved.submission.status, 'approved');

  const main = await call('GET', 'team/workspace/file', { query: { workspace: 'main', path: 'web/checkout.html' } });
  assert.match(main.content, /Pay with UPI/);
  assert.match((await call('GET', 'team/workspace/file', { query: { workspace: 'main', path: 'config/payments.json' } })).content, /"upi"/);

  const restarted = await call('POST', 'team/agent/restart', { as: 'meera' });
  assert.ok(restarted.points.length >= 3);

  const types = new Set((await call('GET', 'team/log')).events.map((e) => e.type));
  for (const t of ['task.context_alert', 'developer.context_choice', 'impact.decision', 'context.changed', 'merge.done', 'review.sent_back', 'agent.restarted']) {
    assert.ok(types.has(t), `log has ${t}`);
  }
});

test('approving work built on files main has since changed reports a merge conflict', async () => {
  // Sana's seeded submission edits server/db/schema.sql; change the same file in main first.
  const files = fake.tables.project_files.find((f) => f.workspace === 'main' && f.path === 'server/db/schema.sql');
  files.content += '\n-- edited directly in main\n';
  const sana = (await call('GET', 'team/review/queue', { as: 'vikram' })).items.find((s) => s.userId === people.sana);
  const r = await call('POST', 'team/review/decide', { as: 'vikram', body: { submissionId: sana.id, action: 'approve' } });
  assert.equal(r.submission.status, 'merge_conflict');
  assert.deepEqual(r.submission.mergeInfo.conflictedFiles, ['server/db/schema.sql']);
});
